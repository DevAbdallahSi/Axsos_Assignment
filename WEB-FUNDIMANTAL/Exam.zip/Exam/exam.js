function changeColor(){
    var buttonCollor = document.querySelector(".join-us-button")
    buttonCollor.style.color = ' #ea592d'
    buttonBackgroundcolor.style.color="white"
}