import { useState, useEffect } from 'react';
import './App.css';
import TodoApp from './components/MyList';

function App() {

  return (
    <>
        <div>
          <TodoApp/>
        </div>
    </>
    
  );
}

export default App;
